<?php get_header();?>
<div class="container">
	<div class="row">
		<div class="conl-xs-12 text-center">
			<h1>Oh No! That Page Doesn't Exist!</h1>
			<img src="<?php echo TEMP_URL;?>/images/404.png" alt="404 Page"/>
			<?php echo get_search_form();?>
		</div>
	</div>
</div>
<?php get_footer();?>